"""Базові типи даних: показник, статус «світлофора», тривога, денний звіт."""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import date, datetime
from enum import IntEnum
from typing import Optional


class Status(IntEnum):
    """Статус «світлофора». Порядок важливий: max() дає найгірший."""
    GREEN = 0
    YELLOW = 1
    RED = 2

    @property
    def emoji(self) -> str:
        return {0: "🟢", 1: "🟡", 2: "🔴"}[int(self)]


def _new_id() -> str:
    return uuid.uuid4().hex


@dataclass(frozen=True)
class Reading:
    """Один вимір з пристрою."""
    astronaut_id: str
    metric: str
    value: float
    ts: datetime
    source: str = "device"
    id: str = field(default_factory=_new_id)


@dataclass
class Alert:
    """Тривога або повідомлення системи. Лише підказка: рішення приймає лікар місії."""
    code: str
    status: Status
    message: str
    recommendation: str = ""
    metric: Optional[str] = None
    requires_doctor: bool = False
    ts: Optional[datetime] = None
    astronaut_id: str = ""
    id: str = field(default_factory=_new_id)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "astronaut_id": self.astronaut_id,
            "ts": self.ts.isoformat() if self.ts else None,
            "code": self.code,
            "metric": self.metric,
            "status": self.status.name,
            "message": self.message,
            "recommendation": self.recommendation,
            "requires_doctor": self.requires_doctor,
        }


@dataclass
class DayReport:
    """Підсумок доби."""
    astronaut_id: str
    day: date
    overall: Status
    metric_status: dict[str, Status]
    means: dict[str, float]
    alerts: list[Alert]
    no_data: list[str]
    rejected_readings: int
    dose_usv: float
    cumulative_dose_msv: float

    def to_dict(self) -> dict:
        return {
            "astronaut_id": self.astronaut_id,
            "day": self.day.isoformat(),
            "overall": self.overall.name,
            "metric_status": {m: s.name for m, s in self.metric_status.items()},
            "means": {m: round(v, 3) for m, v in self.means.items()},
            "alert_ids": [a.id for a in self.alerts],
            "no_data": self.no_data,
            "rejected_readings": self.rejected_readings,
            "dose_usv": round(self.dose_usv, 2),
            "cumulative_dose_msv": round(self.cumulative_dose_msv, 4),
        }
