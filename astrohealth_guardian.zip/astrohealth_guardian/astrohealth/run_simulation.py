"""Запуск сценарію: python -m astrohealth.run_simulation --scenario sick"""
from __future__ import annotations

import argparse
from dataclasses import dataclass, field

from .baseline import Baseline
from .comms import EarthLink, MissionControlStub
from .models import DayReport, Status
from .monitor import HealthMonitor
from .recommendations import DISCLAIMER
from .simulator import SCENARIOS, Simulator

KEY = [("temperature", "T"), ("heart_rate", "ЧСС"), ("spo2", "SpO₂"), ("systolic_bp", "АТ"),
       ("hrv_rmssd", "HRV"), ("sleep_hours", "сон")]


@dataclass
class SimulationResult:
    scenario: str
    reports: list[DayReport] = field(default_factory=list)
    monitor: HealthMonitor | None = None
    sync_log: list[tuple[int, int, int]] = field(default_factory=list)   # (день, надіслано, в черзі)


def run_scenario(name: str, seed: int = 42, baseline_days: int = 28) -> SimulationResult:
    sc = SCENARIOS[name]
    sim = Simulator(seed=seed)
    baseline = Baseline.from_readings(sim.baseline_readings(baseline_days))
    link, earth = EarthLink(), MissionControlStub()
    mon = HealthMonitor(sim.astronaut_id, baseline, link=link, earth=earth)
    res = SimulationResult(name, monitor=mon)
    for d in range(sc.days):
        link.available = sc.comms(d)
        for r in sim.day_readings(d, sc.effects(d)):
            mon.ingest(r)
        res.reports.append(mon.end_of_day(sim.date_of(d)))
        s = mon.sync()
        res.sync_log.append((d + 1, s.sent_alerts, s.pending_alerts))
    return res


def print_result(res: SimulationResult, verbose: bool = True) -> None:
    sc = SCENARIOS[res.scenario]
    print(f"\n=== {sc.title} ({sc.name}) ===\nОчікування: {sc.expectation}\n")
    for i, rep in enumerate(res.reports, 1):
        vals = " ".join(f"{lbl}={rep.means[m]:.1f}" for m, lbl in KEY if m in rep.means)
        print(f"День {i:>2} {rep.overall.emoji}  {vals}")
        if verbose:
            for a in rep.alerts:
                doc = " [потрібен лікар]" if a.requires_doctor else ""
                print(f"        {a.status.emoji} {a.code}{doc}: {a.message}")
                if a.recommendation:
                    print(f"           → {a.recommendation}")
            if rep.rejected_readings:
                print(f"        ⚙ відкинуто артефактів: {rep.rejected_readings}")
    last = res.reports[-1]
    pending = res.monitor.storage.unsynced_alerts()
    print(f"\nНакопичена доза: {last.cumulative_dose_msv:.3f} мЗв | "
          f"на Землі отримано тривог: {len(res.monitor.earth.alerts)} | у черзі: {len(pending)}")
    print(f"ℹ {DISCLAIMER}")


def main() -> None:
    p = argparse.ArgumentParser(description="Симуляція місії AstroHealth Guardian")
    p.add_argument("--scenario", choices=sorted(SCENARIOS), default="sick")
    p.add_argument("--all", action="store_true", help="запустити всі сценарії")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--list", action="store_true", help="показати список сценаріїв")
    p.add_argument("--quiet", action="store_true", help="лише рядки зі статусами")
    a = p.parse_args()
    if a.list:
        for sc in SCENARIOS.values():
            print(f"{sc.name:<15} {sc.title}")
        return
    for name in (sorted(SCENARIOS) if a.all else [a.scenario]):
        print_result(run_scenario(name, a.seed), verbose=not a.quiet)


if __name__ == "__main__":
    main()
