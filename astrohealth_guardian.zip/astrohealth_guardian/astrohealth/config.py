"""Параметри показників і пороги.

УВАГА: числа нижче ілюстративні (загальні клінічні норми та припущення для
навчального проєкту). Медичний консультант команди має звірити їх із джерелами
(NASA HRP, NASA-STD-3001) і за потреби змінити ТІЛЬКИ тут.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

# Налаштування логіки відхилень від особистої норми
Z_YELLOW = 2.0      # |відхилення| > 2σ
Z_RED = 3.0         # |відхилення| > 3σ
TREND_POINTS = 2    # скільки вимірів підряд має тривати відхилення

# Радіація (ілюстративний бюджет дози на місію, мЗв)
MISSION_DOSE_BUDGET_MSV = 600.0
DOSE_WARN_FRACTION = 0.8


@dataclass(frozen=True)
class MetricSpec:
    name: str
    label: str                 # назва для інтерфейсу
    unit: str
    plausible: tuple[float, float]   # поза діапазоном = артефакт датчика
    direction: str             # "both" | "high" | "low": що вважається погіршенням
    min_std: float             # мінімальна σ для базлайну (захист від ділення на ~0)
    max_gap_days: int = 1      # через скільки днів без даних вважаємо «немає даних»
    acute: bool = False        # чи потрібна миттєва реакція на окремий вимір
    red_low: Optional[float] = None
    yellow_low: Optional[float] = None
    yellow_high: Optional[float] = None
    red_high: Optional[float] = None


_SPECS = [
    MetricSpec("heart_rate", "ЧСС у спокої", "уд/хв", (20, 250), "both", 3.0,
               red_low=40, yellow_low=50, yellow_high=90, red_high=110),
    MetricSpec("spo2", "SpO₂", "%", (50, 100), "low", 0.4, acute=True,
               red_low=92, yellow_low=95),
    MetricSpec("temperature", "Температура тіла", "°C", (30, 43), "both", 0.2, acute=True,
               red_low=35.0, yellow_low=36.0, yellow_high=37.2, red_high=38.0),
    MetricSpec("systolic_bp", "Систолічний тиск", "мм рт. ст.", (50, 250), "both", 5.0,
               red_low=90, yellow_low=100, yellow_high=130, red_high=140),
    MetricSpec("hrv_rmssd", "HRV (RMSSD)", "мс", (1, 300), "low", 4.0),
    MetricSpec("sleep_hours", "Сон", "год", (0, 14), "low", 0.4,
               red_low=5.0, yellow_low=6.5),
    MetricSpec("stress_index", "Індекс стресу (голос/міміка)", "0–1", (0, 1), "high", 0.05,
               yellow_high=0.6, red_high=0.85),
    MetricSpec("radiation_rate", "Потужність дози радіації", "мкЗв/год", (0, 100000), "high", 3.0,
               acute=True, yellow_high=60, red_high=200),
    # Тижневі виміри
    MetricSpec("ctx", "CTX (резорбція кісток)", "нг/мл", (0, 10), "high", 0.03, max_gap_days=9),
    MetricSpec("visual_acuity", "Гострота зору", "відн.", (0.05, 2.0), "low", 0.02,
               max_gap_days=9, red_low=0.5, yellow_low=0.8),
]

SPECS: dict[str, MetricSpec] = {s.name: s for s in _SPECS}
