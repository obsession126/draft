"""Локальне сховище на борту (SQLite). Працює без інтернету."""
from __future__ import annotations

import json
import sqlite3
from typing import Iterable, Optional

from .models import Alert, DayReport, Reading, Status

SCHEMA = """
CREATE TABLE IF NOT EXISTS readings (
    id TEXT PRIMARY KEY, astronaut_id TEXT, metric TEXT, value REAL, ts TEXT, source TEXT);
CREATE INDEX IF NOT EXISTS ix_readings ON readings(astronaut_id, metric, ts);
CREATE TABLE IF NOT EXISTS alerts (
    id TEXT PRIMARY KEY, astronaut_id TEXT, ts TEXT, code TEXT, metric TEXT, status INTEGER,
    message TEXT, recommendation TEXT, requires_doctor INTEGER, synced INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS reports (
    astronaut_id TEXT, day TEXT, payload TEXT, synced INTEGER DEFAULT 0,
    PRIMARY KEY (astronaut_id, day));
"""


class Storage:
    def __init__(self, path: str = ":memory:"):
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)

    # --- запис
    def save_reading(self, r: Reading) -> None:
        self.db.execute("INSERT OR IGNORE INTO readings VALUES (?,?,?,?,?,?)",
                        (r.id, r.astronaut_id, r.metric, r.value, r.ts.isoformat(), r.source))
        self.db.commit()

    def save_alert(self, a: Alert) -> None:
        self.db.execute(
            "INSERT OR IGNORE INTO alerts (id, astronaut_id, ts, code, metric, status, message,"
            " recommendation, requires_doctor) VALUES (?,?,?,?,?,?,?,?,?)",
            (a.id, a.astronaut_id, a.ts.isoformat() if a.ts else None, a.code, a.metric,
             int(a.status), a.message, a.recommendation, int(a.requires_doctor)))
        self.db.commit()

    def save_report(self, rep: DayReport) -> None:
        self.db.execute("INSERT OR REPLACE INTO reports (astronaut_id, day, payload, synced) VALUES (?,?,?,0)",
                        (rep.astronaut_id, rep.day.isoformat(), json.dumps(rep.to_dict(), ensure_ascii=False)))
        self.db.commit()

    # --- читання
    def readings(self, astronaut_id: str, metric: str) -> list[dict]:
        rows = self.db.execute("SELECT * FROM readings WHERE astronaut_id=? AND metric=? ORDER BY ts",
                               (astronaut_id, metric)).fetchall()
        return [dict(r) for r in rows]

    def alerts(self, astronaut_id: Optional[str] = None, min_status: Status = Status.GREEN) -> list[dict]:
        q, args = "SELECT * FROM alerts WHERE status>=?", [int(min_status)]
        if astronaut_id:
            q, args = q + " AND astronaut_id=?", args + [astronaut_id]
        return [dict(r) for r in self.db.execute(q + " ORDER BY ts", args).fetchall()]

    def reports(self, astronaut_id: str) -> list[dict]:
        rows = self.db.execute("SELECT payload FROM reports WHERE astronaut_id=? ORDER BY day",
                               (astronaut_id,)).fetchall()
        return [json.loads(r["payload"]) for r in rows]

    # --- черга на відправку на Землю
    def unsynced_alerts(self) -> list[dict]:
        rows = self.db.execute("SELECT * FROM alerts WHERE synced=0 ORDER BY requires_doctor DESC, status DESC, ts").fetchall()
        return [dict(r) for r in rows]

    def unsynced_reports(self) -> list[dict]:
        rows = self.db.execute("SELECT astronaut_id, day, payload FROM reports WHERE synced=0 ORDER BY day").fetchall()
        return [{"astronaut_id": r["astronaut_id"], "day": r["day"], **json.loads(r["payload"])} for r in rows]

    def mark_synced(self, alert_ids: Iterable[str], report_keys: Iterable[tuple[str, str]]) -> None:
        self.db.executemany("UPDATE alerts SET synced=1 WHERE id=?", [(i,) for i in alert_ids])
        self.db.executemany("UPDATE reports SET synced=1 WHERE astronaut_id=? AND day=?", list(report_keys))
        self.db.commit()
