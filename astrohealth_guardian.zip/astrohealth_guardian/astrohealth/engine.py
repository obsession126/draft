"""Рушій прийняття рішень: приймає виміри, формує тривоги й щоденний звіт."""
from __future__ import annotations

import statistics
from collections import defaultdict
from datetime import date, datetime, time, timedelta
from typing import Optional

from .baseline import Baseline
from .config import (DOSE_WARN_FRACTION, MISSION_DOSE_BUDGET_MSV, SPECS, TREND_POINTS,
                     Z_RED, Z_YELLOW, MetricSpec)
from .models import Alert, DayReport, Reading, Status
from .recommendations import METRIC_ADVICE
from .rules import absolute_status, bad_z, evaluate_combined, is_plausible


class HealthEngine:
    def __init__(self, astronaut_id: str, baseline: Baseline,
                 dose_budget_msv: float = MISSION_DOSE_BUDGET_MSV):
        self.astronaut_id = astronaut_id
        self.baseline = baseline
        self.dose_budget_msv = dose_budget_msv
        self.cumulative_dose_usv = 0.0

        self._values: dict[str, list[tuple[datetime, float]]] = defaultdict(list)
        self._instant: list[Alert] = []
        self._instant_fired: set[tuple[date, str]] = set()
        self._rejected = 0
        self._bad_z_history: dict[str, list[float]] = defaultdict(list)
        self._last_seen: dict[str, date] = {}
        self._last_status: dict[str, Status] = {}
        self._radiation_alarm = False
        self._dose_flags: set[str] = set()

    # ------------------------------------------------------------------ вимір
    def ingest(self, r: Reading) -> list[Alert]:
        """Приймає один вимір. Повертає миттєві тривоги (якщо є)."""
        spec = SPECS.get(r.metric)
        if spec is None or not is_plausible(spec, r.value):
            self._rejected += 1          # артефакт/невідомий показник: не використовуємо
            return []
        self._values[r.metric].append((r.ts, r.value))

        fired: list[Alert] = []
        if spec.acute:
            fired = self._instant_check(spec, r)
        self._instant.extend(fired)
        return fired

    def _instant_check(self, spec: MetricSpec, r: Reading) -> list[Alert]:
        out: list[Alert] = []
        if spec.name == "radiation_rate":
            if absolute_status(spec, r.value) == Status.RED and not self._radiation_alarm:
                self._radiation_alarm = True
                out.append(self._alert(
                    "RADIATION_SHELTER", Status.RED, r.ts, spec.name, True,
                    f"Потужність дози {r.value:.0f} {spec.unit}: імовірний сонячний спалах.",
                    METRIC_ADVICE[spec.name][Status.RED]))
            elif self._radiation_alarm and r.value <= (spec.yellow_high or 0):
                self._radiation_alarm = False
                out.append(self._alert(
                    "RADIATION_CLEAR", Status.GREEN, r.ts, spec.name, False,
                    "Потужність дози повернулась до безпечного рівня.",
                    "Можна залишити укриття; перевірте накопичену дозу у звіті."))
            return out

        key = (r.ts.date(), spec.name)
        if absolute_status(spec, r.value) == Status.RED and key not in self._instant_fired:
            self._instant_fired.add(key)
            out.append(self._alert(
                f"{spec.name.upper()}_CRITICAL", Status.RED, r.ts, spec.name, True,
                f"{spec.label}: {r.value:.1f} {spec.unit}: критичне значення.",
                METRIC_ADVICE[spec.name][Status.RED]))
        return out

    # ------------------------------------------------------------- кінець доби
    def close_day(self, day: date) -> DayReport:
        today: dict[str, list[tuple[datetime, float]]] = {}
        for metric in list(self._values):
            mine = [(t, v) for t, v in self._values[metric] if t.date() == day]
            self._values[metric] = [(t, v) for t, v in self._values[metric] if t.date() != day]
            if mine:
                today[metric] = mine

        end = datetime.combine(day, time.max)
        alerts = [a for a in self._instant if a.ts and a.ts.date() == day]
        self._instant = [a for a in self._instant if not (a.ts and a.ts.date() == day)]
        critical_now = {a.metric for a in alerts if a.status == Status.RED and a.metric}

        means: dict[str, float] = {}
        statuses: dict[str, Status] = {}
        no_data: list[str] = []

        for metric, spec in SPECS.items():
            if metric in today:
                mean = statistics.fmean(v for _, v in today[metric])
                means[metric] = mean
                self._last_seen[metric] = day
                if not self.baseline.has(metric):
                    statuses[metric] = absolute_status(spec, mean)
                    continue
                z = self.baseline.z(metric, mean)
                hist = self._bad_z_history[metric]
                hist.append(bad_z(spec, z))
                status = max(absolute_status(spec, mean), self._trend_status(spec, hist))
                if metric in critical_now:
                    status = Status.RED
                statuses[metric] = status
                self._last_status[metric] = status
                if status > Status.GREEN and metric not in critical_now:
                    alerts.append(self._metric_alert(spec, status, mean, z, end))
            elif self.baseline.has(metric):
                last = self._last_seen.setdefault(metric, day - timedelta(days=1))
                if (day - last).days >= spec.max_gap_days:
                    no_data.append(metric)
                elif spec.max_gap_days > 1 and metric in self._last_status:
                    statuses[metric] = self._last_status[metric]   # тижневий показник: статус діє до наступного виміру

        for m in no_data:
            alerts.append(self._alert(
                "DEVICE_NO_DATA", Status.YELLOW, end, m, False,
                f"Немає даних: {SPECS[m].label}.",
                "Перевірте підключення та заряд пристрою; значення не підставляються автоматично."))

        for a in evaluate_combined(statuses):
            a.ts, a.astronaut_id = end, self.astronaut_id
            alerts.append(a)

        dose = self._daily_dose(today.get("radiation_rate", []), day)
        self.cumulative_dose_usv += dose
        alerts.extend(self._dose_alerts(end))

        overall = max((a.status for a in alerts), default=Status.GREEN)
        overall = max([overall, *statuses.values()])
        rejected, self._rejected = self._rejected, 0
        return DayReport(self.astronaut_id, day, overall, statuses, means, alerts,
                         no_data, rejected, dose, self.cumulative_dose_usv / 1000)

    # ---------------------------------------------------------------- допоміжне
    @staticmethod
    def _trend_status(spec: MetricSpec, history: list[float]) -> Status:
        """Статус за відхиленням від особистої норми.

        Якщо для показника є абсолютні пороги, відхилення від базлайну дає максимум 🟡
        (🔴 дають лише критичні пороги). Для показників без порогів (HRV, CTX)
        стійке відхилення >3σ дає 🔴.
        """
        has_abs_limits = any(v is not None for v in (spec.red_low, spec.red_high))
        last = history[-TREND_POINTS:]
        persistent = len(last) == TREND_POINTS
        if persistent and all(z > Z_RED for z in last):
            return Status.YELLOW if has_abs_limits else Status.RED
        if persistent and all(z > Z_YELLOW for z in last):
            return Status.YELLOW
        if history[-1] > Z_RED:      # різкий стрибок: попередження
            return Status.YELLOW
        return Status.GREEN

    def _metric_alert(self, spec: MetricSpec, status: Status, mean: float, z: float,
                      ts: datetime) -> Alert:
        base = self.baseline.stats[spec.name].mean
        advice = METRIC_ADVICE.get(spec.name, {})
        text = advice.get(status) or advice.get(Status.YELLOW, "")
        return self._alert(
            f"{spec.name.upper()}_{status.name}", status, ts, spec.name,
            status == Status.RED,
            f"{spec.label}: {mean:.2f} {spec.unit} ({z:+.1f}σ від вашої норми {base:.2f}).", text)

    @staticmethod
    def _daily_dose(samples: list[tuple[datetime, float]], day: date) -> float:
        """Доза за добу (мкЗв): кожен вимір діє до наступного (або до півночі)."""
        samples = sorted(samples)
        midnight = datetime.combine(day + timedelta(days=1), time.min)
        total = 0.0
        for i, (ts, rate) in enumerate(samples):
            nxt = samples[i + 1][0] if i + 1 < len(samples) else midnight
            total += rate * (nxt - ts).total_seconds() / 3600
        return total

    def _dose_alerts(self, ts: datetime) -> list[Alert]:
        used = self.cumulative_dose_usv / 1000 / self.dose_budget_msv
        out = []
        if used >= 1.0 and "full" not in self._dose_flags:
            self._dose_flags.add("full")
            out.append(self._alert("DOSE_BUDGET_EXCEEDED", Status.RED, ts, "radiation_rate", True,
                                   "Накопичену дозу вичерпано (за прийнятим бюджетом місії).",
                                   "Обмежте перебування поза укриттям. Зверніться до лікаря місії."))
        elif used >= DOSE_WARN_FRACTION and "warn" not in self._dose_flags:
            self._dose_flags.add("warn")
            out.append(self._alert("DOSE_BUDGET_WARNING", Status.YELLOW, ts, "radiation_rate", False,
                                   f"Використано {used:.0%} бюджету радіаційної дози.",
                                   "Плануйте роботи з урахуванням дози."))
        return out

    def _alert(self, code: str, status: Status, ts: Optional[datetime], metric: Optional[str],
               doctor: bool, message: str, recommendation: str) -> Alert:
        return Alert(code=code, status=status, message=message, recommendation=recommendation,
                     metric=metric, requires_doctor=doctor, ts=ts, astronaut_id=self.astronaut_id)
