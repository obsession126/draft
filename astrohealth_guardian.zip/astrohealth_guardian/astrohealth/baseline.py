"""Особистий базлайн астронавта: середнє та σ по добових середніх."""
from __future__ import annotations

import json
import statistics
from collections import defaultdict
from dataclasses import dataclass
from typing import Iterable

from .config import SPECS
from .models import Reading
from .rules import is_plausible


@dataclass(frozen=True)
class MetricBaseline:
    mean: float
    std: float
    n: int


class Baseline:
    MIN_POINTS = 3

    def __init__(self, stats: dict[str, MetricBaseline]):
        self.stats = stats

    @classmethod
    def from_readings(cls, readings: Iterable[Reading]) -> "Baseline":
        """Будує базлайн із вимірів (напр., 4 тижні перед польотом або перші тижні місії)."""
        per_day: dict[str, dict] = defaultdict(lambda: defaultdict(list))
        for r in readings:
            spec = SPECS.get(r.metric)
            if spec and is_plausible(spec, r.value):
                per_day[r.metric][r.ts.date()].append(r.value)

        stats: dict[str, MetricBaseline] = {}
        for metric, days in per_day.items():
            means = [statistics.fmean(v) for v in days.values()]
            if len(means) < cls.MIN_POINTS:
                continue
            std = max(statistics.stdev(means), SPECS[metric].min_std)
            stats[metric] = MetricBaseline(statistics.fmean(means), std, len(means))
        if not stats:
            raise ValueError("Недостатньо даних для побудови базлайну")
        return cls(stats)

    def has(self, metric: str) -> bool:
        return metric in self.stats

    def z(self, metric: str, value: float) -> float:
        b = self.stats[metric]
        return (value - b.mean) / b.std

    def to_json(self) -> str:
        return json.dumps({m: vars(b) for m, b in self.stats.items()}, ensure_ascii=False)

    @classmethod
    def from_json(cls, text: str) -> "Baseline":
        return cls({m: MetricBaseline(**d) for m, d in json.loads(text).items()})
