"""Прозорі правила: абсолютні пороги, відхилення від базлайну, комбіновані правила."""
from __future__ import annotations

from .config import SPECS, MetricSpec
from .models import Alert, Status
from .recommendations import COMBINED_ADVICE


def is_plausible(spec: MetricSpec, value: float) -> bool:
    lo, hi = spec.plausible
    return lo <= value <= hi


def absolute_status(spec: MetricSpec, value: float) -> Status:
    """Статус за абсолютними порогами (якщо вони задані для показника)."""
    if spec.red_low is not None and value < spec.red_low:
        return Status.RED
    if spec.red_high is not None and value > spec.red_high:
        return Status.RED
    if spec.yellow_low is not None and value < spec.yellow_low:
        return Status.YELLOW
    if spec.yellow_high is not None and value > spec.yellow_high:
        return Status.YELLOW
    return Status.GREEN


def bad_z(spec: MetricSpec, z: float) -> float:
    """Перетворює z-оцінку на «наскільки гірше за норму» (додатне = гірше)."""
    if spec.direction == "high":
        return z
    if spec.direction == "low":
        return -z
    return abs(z)


def evaluate_combined(statuses: dict[str, Status]) -> list[Alert]:
    """Комбіновані правила: кілька показників разом дають більш певний висновок."""
    get = lambda m: statuses.get(m, Status.GREEN)  # noqa: E731
    alerts: list[Alert] = []

    # 1) Імовірна інфекція: температура + ще щось із (ЧСС, сон, SpO₂, HRV)
    temp = get("temperature")
    others = [m for m in ("heart_rate", "sleep_hours", "spo2", "hrv_rmssd") if get(m) >= Status.YELLOW]
    if temp >= Status.YELLOW and others:
        st = Status.RED if temp == Status.RED else Status.YELLOW
        names = ", ".join(SPECS[m].label for m in others)
        code = "INFECTION_SUSPECTED" if st == Status.RED else "INFECTION_POSSIBLE"
        alerts.append(Alert(
            code=code, status=st, metric=None, requires_doctor=(st == Status.RED),
            message=f"Температура разом із відхиленнями ({names}): {'імовірна інфекція' if st == Status.RED else 'можлива хвороба'}.",
            recommendation=COMBINED_ADVICE[code]))

    # 2) Ризик стресу/депресії: HRV, індекс стресу, сон
    group = [m for m in ("hrv_rmssd", "stress_index", "sleep_hours") if get(m) >= Status.YELLOW]
    if len(group) >= 2:
        st = Status.RED if len(group) == 3 else Status.YELLOW
        code = "STRESS_RISK_HIGH" if st == Status.RED else "STRESS_RISK"
        alerts.append(Alert(
            code=code, status=st, metric=None, requires_doctor=(st == Status.RED),
            message="Комбінація ознак перевантаження: " + ", ".join(SPECS[m].label for m in group) + ".",
            recommendation=COMBINED_ADVICE[code]))

    # 3) Навантаження на серцево-судинну систему: ЧСС і тиск разом
    if get("heart_rate") >= Status.YELLOW and get("systolic_bp") >= Status.YELLOW:
        st = max(get("heart_rate"), get("systolic_bp"))
        alerts.append(Alert(
            code="CARDIO_STRAIN", status=st, metric=None, requires_doctor=(st == Status.RED),
            message="Одночасні відхилення ЧСС і артеріального тиску.",
            recommendation=COMBINED_ADVICE["CARDIO_STRAIN"]))
    return alerts
