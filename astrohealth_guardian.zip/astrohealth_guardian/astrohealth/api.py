"""Необов'язковий REST API (FastAPI). Запуск: uvicorn astrohealth.api:app --reload

Потрібно: pip install fastapi uvicorn. Ядро системи від API не залежить.
"""
from __future__ import annotations

from datetime import date, datetime

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from .baseline import Baseline
from .models import Reading, Status
from .monitor import HealthMonitor
from .simulator import Simulator

app = FastAPI(title="AstroHealth Guardian")

# Демо: базлайн із симулятора. У реальній системі його беруть із профілю астронавта.
_monitor = HealthMonitor("A-01", Baseline.from_readings(Simulator(seed=1).baseline_readings(28)))


class ReadingIn(BaseModel):
    metric: str
    value: float
    ts: datetime | None = None
    source: str = "device"


@app.post("/readings")
def post_reading(r: ReadingIn):
    alerts = _monitor.ingest(Reading("A-01", r.metric, r.value, r.ts or datetime.utcnow(), r.source))
    return {"alerts": [a.to_dict() for a in alerts]}


@app.post("/days/{day}/close")
def close_day(day: date):
    rep = _monitor.end_of_day(day)
    return {**rep.to_dict(), "light": rep.overall.emoji,
            "alerts": [a.to_dict() for a in rep.alerts]}


@app.get("/reports")
def reports():
    return _monitor.storage.reports("A-01")


@app.get("/alerts")
def alerts(min_status: str = "YELLOW"):
    if min_status not in Status.__members__:
        raise HTTPException(400, "min_status: GREEN | YELLOW | RED")
    return _monitor.storage.alerts("A-01", Status[min_status])


@app.post("/sync")
def sync():
    return vars(_monitor.sync())
