"""Оркестратор: пристрій → рушій → сховище → зв'язок із Землею."""
from __future__ import annotations

from datetime import date
from typing import Optional

from .baseline import Baseline
from .comms import EarthLink, MissionControlStub, SyncResult, sync_to_earth
from .engine import HealthEngine
from .models import Alert, DayReport, Reading
from .storage import Storage


class HealthMonitor:
    def __init__(self, astronaut_id: str, baseline: Baseline, storage: Optional[Storage] = None,
                 link: Optional[EarthLink] = None, earth: Optional[MissionControlStub] = None, **engine_kw):
        self.engine = HealthEngine(astronaut_id, baseline, **engine_kw)
        self.storage = storage or Storage()
        self.link = link or EarthLink()
        self.earth = earth or MissionControlStub()

    def ingest(self, r: Reading) -> list[Alert]:
        self.storage.save_reading(r)
        alerts = self.engine.ingest(r)
        for a in alerts:
            self.storage.save_alert(a)
        return alerts

    def end_of_day(self, day: date) -> DayReport:
        report = self.engine.close_day(day)
        for a in report.alerts:           # миттєві тривоги вже збережені (INSERT OR IGNORE)
            self.storage.save_alert(a)
        self.storage.save_report(report)
        return report

    def sync(self) -> SyncResult:
        return sync_to_earth(self.storage, self.link, self.earth)
