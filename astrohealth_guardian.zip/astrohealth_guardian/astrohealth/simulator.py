"""Симулятор пристроїв і сценаріїв місії (реального обладнання немає, тож тестуємо на симуляції)."""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta
from typing import Callable

from .models import Reading

# метрика: (типове значення астронавта, шум одного виміру)
PROFILE = {
    "heart_rate": (62.0, 2.0), "spo2": (98.0, 0.4), "temperature": (36.6, 0.1),
    "systolic_bp": (118.0, 4.0), "hrv_rmssd": (55.0, 5.0), "stress_index": (0.25, 0.04),
    "sleep_hours": (7.5, 0.3), "radiation_rate": (20.0, 2.0),
    "ctx": (0.45, 0.03), "visual_acuity": (1.0, 0.015),
}
CONTINUOUS = ["heart_rate", "spo2", "temperature", "systolic_bp", "hrv_rmssd", "stress_index"]
ARTIFACT_VALUE = {"heart_rate": 300.0, "spo2": 0.0, "temperature": 0.0, "systolic_bp": 0.0,
                  "hrv_rmssd": 0.0, "stress_index": 5.0}
CLIP = {"spo2": (0, 100), "stress_index": (0, 1), "visual_acuity": (0, 2)}


@dataclass
class DayEffects:
    offsets: dict[str, float] = field(default_factory=dict)   # зсув середнього показника
    dropout: set[str] = field(default_factory=set)            # датчик не віддає даних
    flare: dict[int, float] = field(default_factory=dict)     # година -> мкЗв/год
    artifact_prob: float = 0.0                                # ймовірність «сміття» від датчика


@dataclass
class Scenario:
    name: str
    title: str
    days: int
    expectation: str
    effects: Callable[[int], DayEffects] = lambda d: DayEffects()
    comms: Callable[[int], bool] = lambda d: True


class Simulator:
    def __init__(self, astronaut_id: str = "A-01", seed: int = 42, start: date = date(2035, 3, 1)):
        self.astronaut_id = astronaut_id
        self.start = start
        self.rng = random.Random(seed)

    def date_of(self, day_index: int) -> date:
        return self.start + timedelta(days=day_index)

    def _value(self, metric: str, fx: DayEffects) -> float:
        mean, noise = PROFILE[metric]
        v = mean + fx.offsets.get(metric, 0.0) + self.rng.gauss(0, noise)
        lo, hi = CLIP.get(metric, (float("-inf"), float("inf")))
        return min(max(v, lo), hi)

    def day_readings(self, day_index: int, fx: DayEffects | None = None) -> list[Reading]:
        fx = fx or DayEffects()
        d = self.date_of(day_index)
        out: list[Reading] = []

        def add(metric: str, hour: int, value: float) -> None:
            if metric in fx.dropout:
                return
            if self.rng.random() < fx.artifact_prob and metric in ARTIFACT_VALUE:
                value = ARTIFACT_VALUE[metric]
            out.append(Reading(self.astronaut_id, metric, value, datetime.combine(d, time(hour)), "sim"))

        for hour in (0, 6, 12, 18):
            for m in CONTINUOUS:
                add(m, hour, self._value(m, fx))
        add("sleep_hours", 7, self._value("sleep_hours", fx))
        if day_index % 7 == 0:                                    # тижневі виміри
            add("ctx", 9, self._value("ctx", fx))
            add("visual_acuity", 9, self._value("visual_acuity", fx))

        rad = {h: self._value("radiation_rate", fx) for h in (0, 6, 12, 18)}
        rad.update(fx.flare)
        for h in sorted(rad):
            add("radiation_rate", h, rad[h])
        return out

    def baseline_readings(self, days: int = 28) -> list[Reading]:
        """Виміри «до польоту»: days днів без жодних подій."""
        out: list[Reading] = []
        for i in range(-days, 0):
            out += self.day_readings(i)
        return out


# ---------------------------------------------------------------- сценарії
def _table(table: dict[int, dict[str, float]]) -> Callable[[int], DayEffects]:
    return lambda d: DayEffects(offsets=table.get(d, {}))


def _stress(d: int) -> DayEffects:
    ramp = {4: 0.3, 5: 0.6, 6: 1.0, 7: 1.0, 8: 1.0, 9: 1.0, 10: 0.6, 11: 0.3}.get(d, 0.0)
    return DayEffects(offsets={"hrv_rmssd": -15 * ramp, "stress_index": 0.4 * ramp, "sleep_hours": -1.5 * ramp})


def _comms_events(d: int) -> DayEffects:
    if 6 <= d <= 8:
        return DayEffects(offsets={"systolic_bp": 14})
    if d == 9:
        return DayEffects(offsets={"spo2": -8})
    return DayEffects()


SCENARIOS: dict[str, Scenario] = {s.name: s for s in [
    Scenario("normal", "Норма: усе спокійно", 14,
             "Усі дні 🟢, жодних хибних тривог."),
    Scenario("sick", "Астронавт захворів", 10,
             "День 3: 🟡 можлива хвороба; день 4–5: 🔴 імовірна інфекція; далі одужання.",
             _table({2: {"temperature": 0.8, "heart_rate": 4, "sleep_hours": -1.3},
                     3: {"temperature": 1.7, "heart_rate": 25, "spo2": -4.0, "sleep_hours": -2.5},
                     4: {"temperature": 1.4, "heart_rate": 18, "spo2": -3.0, "sleep_hours": -2.0},
                     5: {"temperature": 0.5, "heart_rate": 8, "sleep_hours": -1.0}})),
    Scenario("solar_flare", "Сонячний спалах", 10,
             "День 5: одна 🔴 тривога «в укриття», потім повідомлення «відбій»; доза накопичена.",
             lambda d: DayEffects(flare={10: 80, 11: 450, 12: 700, 13: 500, 14: 250, 15: 90}) if d == 4 else DayEffects()),
    Scenario("comms_loss", "Втрата зв'язку із Землею", 20,
             "Зв'язку немає дні 4–12 (нумерація звіту): тривоги копичаться локально, після відновлення йдуть на Землю один раз, критичні першими.",
             _comms_events, comms=lambda d: not (3 <= d <= 11)),
    Scenario("stress", "Стрес і недосип", 16,
             "HRV↓, стрес↑, сон↓: 🟡 → 🔴 «ризик стресу», рекомендація психолога.", _stress),
    Scenario("bone_loss", "Повільна втрата кісткової маси", 49,
             "CTX росте тижнями: спершу 🟡 з рекомендацією тренувань, потім 🔴.",
             lambda d: DayEffects(offsets={"ctx": 0.03 * (d // 7)})),
    Scenario("device_failure", "Збій датчика", 8,
             "Дні 4–5 немає SpO₂ і ЧСС: 🟡 «немає даних», значення не вигадуються.",
             lambda d: DayEffects(dropout={"spo2", "heart_rate"}) if d in (3, 4) else DayEffects()),
    Scenario("artifacts", "Шум і артефакти датчиків", 10,
             "Нереальні значення (ЧСС=300, SpO₂=0) відкидаються, хибних 🔴 немає.",
             lambda d: DayEffects(artifact_prob=0.15)),
]}
