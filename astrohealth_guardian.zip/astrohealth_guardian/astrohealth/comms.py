"""Зв'язок із Землею: пакетна синхронізація з підтвердженням (ack), без дублікатів."""
from __future__ import annotations

import gzip
import json
from dataclasses import dataclass, field

from .storage import Storage


class EarthLink:
    """Імітація каналу зв'язку (на Марсі затримка 20–40 хв в один бік)."""
    def __init__(self, available: bool = True, delay_min: int = 20):
        self.available = available
        self.delay_min = delay_min


class MissionControlStub:
    """«Земля»: приймає пакети, ігнорує дублікати, повертає підтвердження."""
    def __init__(self):
        self.alerts: dict[str, dict] = {}
        self.reports: dict[tuple[str, str], dict] = {}
        self.packets_received = 0

    def receive(self, packet: bytes) -> dict:
        data = json.loads(gzip.decompress(packet))
        self.packets_received += 1
        for a in data["alerts"]:
            self.alerts.setdefault(a["id"], a)
        for r in data["reports"]:
            self.reports.setdefault((r["astronaut_id"], r["day"]), r)
        return {"alert_ids": [a["id"] for a in data["alerts"]],
                "report_keys": [(r["astronaut_id"], r["day"]) for r in data["reports"]]}


@dataclass
class SyncResult:
    sent_alerts: int = 0
    sent_reports: int = 0
    pending_alerts: int = 0
    packet_bytes: int = 0
    note: str = ""


def sync_to_earth(storage: Storage, link: EarthLink, earth: MissionControlStub) -> SyncResult:
    """Надсилає накопичене. Критичні тривоги йдуть першими. Без зв'язку нічого не втрачається."""
    alerts, reports = storage.unsynced_alerts(), storage.unsynced_reports()
    if not link.available:
        return SyncResult(pending_alerts=len(alerts), note="немає зв'язку: дані збережено локально")
    if not alerts and not reports:
        return SyncResult(note="нічого відправляти")
    packet = gzip.compress(json.dumps({"alerts": alerts, "reports": reports}, ensure_ascii=False).encode())
    ack = earth.receive(packet)
    storage.mark_synced(ack["alert_ids"], ack["report_keys"])
    return SyncResult(len(alerts), len(reports), 0, len(packet), "відправлено")
