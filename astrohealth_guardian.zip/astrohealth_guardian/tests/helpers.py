from datetime import date, datetime, time

from astrohealth.baseline import Baseline
from astrohealth.engine import HealthEngine
from astrohealth.models import Reading
from astrohealth.simulator import Simulator

DAY0 = date(2035, 3, 1)


def make_baseline(seed: int = 1) -> Baseline:
    return Baseline.from_readings(Simulator(seed=seed).baseline_readings(28))


def make_engine(**kw) -> HealthEngine:
    return HealthEngine("A-01", make_baseline(), **kw)


def reading(metric: str, value: float, hour: int = 12, day: date = DAY0) -> Reading:
    return Reading("A-01", metric, value, datetime.combine(day, time(hour)))
