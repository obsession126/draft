import pytest

from astrohealth.config import SPECS
from astrohealth.models import Status
from astrohealth.rules import absolute_status, bad_z, evaluate_combined, is_plausible

G, Y, R = Status.GREEN, Status.YELLOW, Status.RED


@pytest.mark.parametrize("metric, value, expected", [
    ("spo2", 98, G), ("spo2", 94, Y), ("spo2", 91.9, R), ("spo2", 95, G),
    ("temperature", 36.6, G), ("temperature", 37.5, Y), ("temperature", 38.1, R), ("temperature", 34.9, R),
    ("heart_rate", 70, G), ("heart_rate", 95, Y), ("heart_rate", 45, Y), ("heart_rate", 120, R), ("heart_rate", 35, R),
    ("systolic_bp", 120, G), ("systolic_bp", 135, Y), ("systolic_bp", 95, Y), ("systolic_bp", 145, R),
    ("sleep_hours", 7.5, G), ("sleep_hours", 6.0, Y), ("sleep_hours", 4.5, R),
    ("radiation_rate", 20, G), ("radiation_rate", 100, Y), ("radiation_rate", 450, R),
    ("hrv_rmssd", 5, G),  # для HRV абсолютних порогів немає: лише базлайн
])
def test_absolute_status(metric, value, expected):
    assert absolute_status(SPECS[metric], value) == expected


@pytest.mark.parametrize("metric, value, ok", [
    ("heart_rate", 300, False), ("heart_rate", 70, True), ("spo2", 0, False),
    ("spo2", 100, True), ("temperature", 0, False), ("stress_index", 5, False),
])
def test_plausibility(metric, value, ok):
    assert is_plausible(SPECS[metric], value) is ok


def test_bad_z_direction():
    assert bad_z(SPECS["hrv_rmssd"], -3) == 3      # низька HRV = погано
    assert bad_z(SPECS["ctx"], 3) == 3             # високий CTX = погано
    assert bad_z(SPECS["ctx"], -3) == -3           # низький CTX = не погано
    assert bad_z(SPECS["heart_rate"], -3) == 3     # ЧСС: погано в обидва боки


def codes(statuses):
    return {a.code for a in evaluate_combined(statuses)}


def test_combined_infection():
    assert codes({"temperature": Y, "sleep_hours": Y}) == {"INFECTION_POSSIBLE"}
    assert "INFECTION_SUSPECTED" in codes({"temperature": R, "heart_rate": Y})
    assert codes({"temperature": Y}) == set()                  # лише температура: без комбінації
    assert codes({"heart_rate": Y, "sleep_hours": Y}) == set()  # без температури: не інфекція


def test_combined_stress():
    assert codes({"hrv_rmssd": Y, "sleep_hours": Y}) == {"STRESS_RISK"}
    assert codes({"hrv_rmssd": Y, "stress_index": Y, "sleep_hours": Y}) == {"STRESS_RISK_HIGH"}
    assert codes({"hrv_rmssd": Y}) == set()


def test_combined_cardio_and_requires_doctor():
    alerts = evaluate_combined({"heart_rate": R, "systolic_bp": Y})
    assert alerts[0].code == "CARDIO_STRAIN" and alerts[0].requires_doctor
