import pytest

from astrohealth.baseline import Baseline
from astrohealth.config import SPECS
from astrohealth.simulator import Simulator

from helpers import make_baseline


def test_baseline_close_to_profile():
    b = make_baseline()
    assert b.stats["heart_rate"].mean == pytest.approx(62, abs=1.5)
    assert b.stats["spo2"].mean == pytest.approx(98, abs=0.5)
    assert b.stats["ctx"].n == 4            # тижневий показник: 4 виміри за 28 днів


def test_std_never_below_floor():
    b = make_baseline()
    for metric, stat in b.stats.items():
        assert stat.std >= SPECS[metric].min_std


def test_z_score_sign():
    b = make_baseline()
    assert b.z("heart_rate", b.stats["heart_rate"].mean + b.stats["heart_rate"].std) == pytest.approx(1.0)


def test_artifacts_are_ignored():
    sim = Simulator(seed=3)
    readings = sim.baseline_readings(28)
    noisy = [r.__class__(r.astronaut_id, r.metric, 300.0 if r.metric == "heart_rate" and i % 9 == 0 else r.value, r.ts)
             for i, r in enumerate(readings)]
    assert Baseline.from_readings(noisy).stats["heart_rate"].mean < 70


def test_too_little_data_raises():
    with pytest.raises(ValueError):
        Baseline.from_readings(Simulator().day_readings(0))


def test_json_roundtrip():
    b = make_baseline()
    assert Baseline.from_json(b.to_json()).stats == b.stats
