"""Сценарії симуляції місії (end-to-end): що саме має зробити система."""
import pytest

from astrohealth.models import Status
from astrohealth.run_simulation import run_scenario
from astrohealth.simulator import SCENARIOS


def codes(report):
    return {a.code for a in report.alerts}


def all_codes(res):
    return {c for r in res.reports for c in codes(r)}


def test_all_scenarios_run():
    for name, sc in SCENARIOS.items():
        assert len(run_scenario(name).reports) == sc.days


@pytest.mark.parametrize("seed", range(10))
def test_normal_has_no_red_alarms(seed):
    res = run_scenario("normal", seed)
    assert max(r.overall for r in res.reports) < Status.RED


def test_normal_false_alarm_rate_is_low():
    bad = sum(max(r.overall for r in run_scenario("normal", s).reports) > Status.GREEN for s in range(30))
    assert bad / 30 <= 0.10


def test_sick_scenario():
    r = run_scenario("sick").reports
    assert r[1].overall == Status.GREEN                         # день 2: усе добре
    assert "INFECTION_POSSIBLE" in codes(r[2]) and r[2].overall == Status.YELLOW
    assert "INFECTION_SUSPECTED" in codes(r[3]) and r[3].overall == Status.RED
    assert any(a.requires_doctor for a in r[3].alerts)
    assert r[-1].overall == Status.GREEN                         # одужання


def test_solar_flare_scenario():
    res = run_scenario("solar_flare")
    flare_day = res.reports[4]
    shelter = [a for a in flare_day.alerts if a.code == "RADIATION_SHELTER"]
    assert len(shelter) == 1 and "укриття" in shelter[0].recommendation
    assert "RADIATION_CLEAR" in codes(flare_day)
    assert flare_day.dose_usv > 3 * res.reports[3].dose_usv     # доза за добу спалаху помітно більша
    assert res.reports[-1].overall == Status.GREEN


def test_comms_loss_scenario():
    res = run_scenario("comms_loss")
    log = {day: (sent, pending) for day, sent, pending in res.sync_log}
    assert all(log[d][0] == 0 for d in range(4, 13))             # у «тиші» (дні 4–12) нічого не відправлено
    assert log[10][1] >= 1                                       # але тривоги чекають у черзі
    assert log[13][0] >= 1 and log[13][1] == 0                   # після відновлення відправлено все
    assert res.monitor.storage.unsynced_alerts() == []
    assert "SPO2_CRITICAL" in {a["code"] for a in res.monitor.earth.alerts.values()}
    assert len(res.monitor.earth.alerts) == len(res.monitor.storage.alerts())   # без дублікатів і втрат


def test_stress_scenario_escalates():
    res = run_scenario("stress")
    assert "STRESS_RISK" in all_codes(res) and "STRESS_RISK_HIGH" in all_codes(res)
    assert res.reports[-1].overall == Status.GREEN


def test_bone_loss_scenario_yellow_then_red():
    res = run_scenario("bone_loss")
    first_ctx = [r for r in res.reports if "CTX_YELLOW" in codes(r)]
    first_red = [r for r in res.reports if "CTX_RED" in codes(r)]
    assert first_ctx and first_red and first_ctx[0].day < first_red[0].day
    assert not any(c.startswith("CTX") for r in res.reports[:14] for c in codes(r))   # перші 2 тижні тихо
    assert "ARED" in next(a for a in first_ctx[0].alerts if a.code == "CTX_YELLOW").recommendation


def test_device_failure_scenario():
    res = run_scenario("device_failure")
    for i in (3, 4):
        rep = res.reports[i]
        assert {"spo2", "heart_rate"} <= set(rep.no_data) and "spo2" not in rep.means
        assert "DEVICE_NO_DATA" in codes(rep)
    assert res.reports[5].overall == Status.GREEN


@pytest.mark.parametrize("seed", range(10))
def test_artifacts_scenario_no_false_red(seed):
    res = run_scenario("artifacts", seed)
    assert sum(r.rejected_readings for r in res.reports) > 0
    assert max(r.overall for r in res.reports) < Status.RED
