from datetime import timedelta

from astrohealth.baseline import Baseline
from astrohealth.comms import EarthLink, MissionControlStub, sync_to_earth
from astrohealth.models import Alert, Status
from astrohealth.monitor import HealthMonitor
from astrohealth.storage import Storage

from helpers import DAY0, make_baseline, reading


def make_monitor(available=True):
    link = EarthLink(available=available)
    return HealthMonitor("A-01", make_baseline(), link=link, earth=MissionControlStub()), link


def test_alerts_and_readings_persist():
    mon, _ = make_monitor()
    mon.ingest(reading("spo2", 90))
    mon.end_of_day(DAY0)
    assert len(mon.storage.readings("A-01", "spo2")) == 1
    assert any(a["code"] == "SPO2_CRITICAL" for a in mon.storage.alerts("A-01"))
    assert len(mon.storage.reports("A-01")) == 1


def test_instant_alert_not_stored_twice():
    mon, _ = make_monitor()
    mon.ingest(reading("spo2", 90))
    mon.end_of_day(DAY0)
    assert sum(a["code"] == "SPO2_CRITICAL" for a in mon.storage.alerts()) == 1


def test_no_link_keeps_data_then_delivers_once():
    mon, link = make_monitor(available=False)
    mon.ingest(reading("spo2", 90))
    mon.end_of_day(DAY0)
    res = mon.sync()
    assert res.sent_alerts == 0 and res.pending_alerts >= 1 and mon.earth.packets_received == 0

    link.available = True
    assert mon.sync().sent_alerts >= 1
    n = len(mon.earth.alerts)
    again = mon.sync()                               # повторна синхронізація: нічого нового
    assert again.sent_alerts == 0 and len(mon.earth.alerts) == n


def test_critical_alerts_go_first():
    st = Storage()
    low = Alert("A_LOW", Status.YELLOW, "x", astronaut_id="A-01", ts=reading("spo2", 1).ts)
    high = Alert("A_HIGH", Status.RED, "y", requires_doctor=True, astronaut_id="A-01", ts=reading("spo2", 1).ts)
    st.save_alert(low)
    st.save_alert(high)
    assert [a["code"] for a in st.unsynced_alerts()] == ["A_HIGH", "A_LOW"]


def test_earth_ignores_duplicates():
    st, earth, link = Storage(), MissionControlStub(), EarthLink()
    a = Alert("X", Status.RED, "m", astronaut_id="A-01", ts=reading("spo2", 1).ts)
    st.save_alert(a)
    sync_to_earth(st, link, earth)
    st.db.execute("UPDATE alerts SET synced=0")      # імітуємо втрату підтвердження
    sync_to_earth(st, link, earth)
    assert len(earth.alerts) == 1                    # дубліката немає
