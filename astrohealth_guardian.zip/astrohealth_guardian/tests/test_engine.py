from datetime import timedelta

import pytest

from astrohealth.models import Status

from helpers import DAY0, make_engine, reading


def feed(engine, metric, value, day=DAY0, hours=(0, 6, 12, 18)):
    for h in hours:
        engine.ingest(reading(metric, value, h, day))


def test_artifact_is_rejected_not_used():
    e = make_engine()
    assert e.ingest(reading("heart_rate", 300)) == []
    assert e.ingest(reading("spo2", 0)) == []
    assert e.ingest(reading("unknown_metric", 1)) == []
    rep = e.close_day(DAY0)
    assert rep.rejected_readings == 3
    assert "heart_rate" not in rep.means


def test_critical_spo2_instant_alert_once_per_day():
    e = make_engine()
    first = e.ingest(reading("spo2", 90, 6))
    again = e.ingest(reading("spo2", 89, 12))
    assert [a.code for a in first] == ["SPO2_CRITICAL"] and first[0].requires_doctor
    assert again == []                                        # без спаму
    rep = e.close_day(DAY0)
    assert sum(a.code == "SPO2_CRITICAL" for a in rep.alerts) == 1
    assert rep.overall == Status.RED


def test_radiation_shelter_alarm_and_clear():
    e = make_engine()
    assert e.ingest(reading("radiation_rate", 20, 8)) == []
    a = e.ingest(reading("radiation_rate", 450, 10))
    assert [x.code for x in a] == ["RADIATION_SHELTER"]
    assert e.ingest(reading("radiation_rate", 700, 11)) == []  # тривога вже активна
    assert e.ingest(reading("radiation_rate", 90, 14)) == []   # ще вище норми: без відбою
    clear = e.ingest(reading("radiation_rate", 20, 18))
    assert [x.code for x in clear] == ["RADIATION_CLEAR"] and clear[0].status == Status.GREEN


def test_dose_integration():
    e = make_engine()
    e.ingest(reading("radiation_rate", 100, 0))   # 100 мкЗв/год × 24 год = 2400 мкЗв
    rep = e.close_day(DAY0)
    assert rep.dose_usv == pytest.approx(2400)
    assert rep.cumulative_dose_msv == pytest.approx(2.4)


def test_dose_budget_warning_and_exceeded():
    e = make_engine(dose_budget_msv=10.0)
    e.ingest(reading("radiation_rate", 15, 0))    # 0.36 мЗв/добу: ще мало
    assert "DOSE_BUDGET_WARNING" not in {a.code for a in e.close_day(DAY0).alerts}
    e.cumulative_dose_usv = 8500                  # 85% бюджету
    codes = {a.code for a in e.close_day(DAY0 + timedelta(days=1)).alerts}
    assert "DOSE_BUDGET_WARNING" in codes
    e.cumulative_dose_usv = 12000
    codes = {a.code for a in e.close_day(DAY0 + timedelta(days=2)).alerts}
    assert "DOSE_BUDGET_EXCEEDED" in codes


def test_missing_sensor_gives_no_data_alert_not_invented_values():
    e = make_engine()
    feed(e, "temperature", 36.6)                  # решти показників немає
    rep = e.close_day(DAY0)
    assert "spo2" in rep.no_data and "spo2" not in rep.means
    assert "DEVICE_NO_DATA" in {a.code for a in rep.alerts}


def test_single_deviation_is_not_enough_for_yellow_under_3_sigma():
    e = make_engine()
    mean = e.baseline.stats["sleep_hours"].mean
    feed(e, "sleep_hours", mean - 1.5 * e.baseline.stats["sleep_hours"].std, hours=(7,))
    rep = e.close_day(DAY0)
    assert rep.metric_status["sleep_hours"] == Status.GREEN


def test_persistent_deviation_escalates_yellow():
    e = make_engine()
    b = e.baseline.stats["stress_index"]
    for i in range(2):                             # 2 доби поспіль +2.5σ (але нижче абсолютного порога)
        feed(e, "stress_index", b.mean + 2.5 * b.std, day=DAY0 + timedelta(days=i))
        rep = e.close_day(DAY0 + timedelta(days=i))
    assert rep.metric_status["stress_index"] == Status.YELLOW


def test_metrics_without_absolute_limits_can_go_red_on_persistent_3_sigma():
    e = make_engine()
    b = e.baseline.stats["hrv_rmssd"]
    for i in range(2):
        feed(e, "hrv_rmssd", b.mean - 3.5 * b.std, day=DAY0 + timedelta(days=i))
        rep = e.close_day(DAY0 + timedelta(days=i))
    assert rep.metric_status["hrv_rmssd"] == Status.RED


def test_deviation_with_absolute_limits_never_red_without_critical_value():
    e = make_engine()
    for i in range(3):                             # ЧСС 80: далеко від норми (62), але не критично
        feed(e, "heart_rate", 80, day=DAY0 + timedelta(days=i))
        rep = e.close_day(DAY0 + timedelta(days=i))
    assert rep.metric_status["heart_rate"] == Status.YELLOW


def test_recovery_returns_to_green():
    e = make_engine()
    b = e.baseline.stats["heart_rate"]
    for i in range(2):
        feed(e, "heart_rate", 85, day=DAY0 + timedelta(days=i))
        e.close_day(DAY0 + timedelta(days=i))
    feed(e, "heart_rate", b.mean, day=DAY0 + timedelta(days=2))
    assert e.close_day(DAY0 + timedelta(days=2)).metric_status["heart_rate"] == Status.GREEN


def test_every_alert_with_red_requires_known_advice():
    e = make_engine()
    e.ingest(reading("temperature", 38.6))
    rep = e.close_day(DAY0)
    for a in rep.alerts:
        assert a.recommendation, f"{a.code} без рекомендації"
